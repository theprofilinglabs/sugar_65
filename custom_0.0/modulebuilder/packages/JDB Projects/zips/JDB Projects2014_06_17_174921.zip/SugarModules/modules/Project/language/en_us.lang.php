<?php 
 // created: 2014-06-17 17:49:19
$mod_strings['LBL_DESCRIPTION'] = 'Description:';

?>
