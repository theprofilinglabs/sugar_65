<?php
 // created: 2014-06-17 11:10:20
$dictionary['Project']['fields']['description']['comments']='Project description';
$dictionary['Project']['fields']['description']['merge_filter']='disabled';
$dictionary['Project']['fields']['description']['rows']='20';
$dictionary['Project']['fields']['description']['cols']='200';

 ?>