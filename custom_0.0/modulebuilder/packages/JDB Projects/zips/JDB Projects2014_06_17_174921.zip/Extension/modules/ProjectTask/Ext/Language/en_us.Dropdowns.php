<?php 
 // created: 2014-06-03 15:46:06
$mod_strings['LBL_JAM01_JDB_COMPANY_PROJECTTASK_1_FROM_JAM01_JDB_COMPANY_TITLE'] = 'Jamitin Company';

?>
