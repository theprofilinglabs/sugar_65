<?php 
$app_list_strings['JDB_ownership_list'] = array (
  'EducationalInstitution' => 'Educational Institution',
  'GovernmentAgency' => 'Government Agency',
  'Nonprofit' => 'Non profit',
  'Partnership' => 'Partnership',
  'PrivatelyHeld' => 'Privately Held',
  'PublicCompany' => 'Public Company',
  'SelfEmployed' => 'Self Employed',
  'SoleProprietorship' => 'Sole Proprietorship',
  'TBC' => 'TBC',
);$app_list_strings['JDB_totalstaff_list'] = array (
  '1-10' => '1-10',
  '11-50' => '11-50',
  '51-200' => '51-200',
  '201-500' => '201-500',
  '501-1000' => '501-1000',
  '1001-5000' => '1001-5000',
  '5001-10000' => '5,001-10,000',
  '10001+' => '10,001+',
  'TBC' => 'Tbc',
  '' => '',
);