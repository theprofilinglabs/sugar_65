<?php
// created: 2014-05-22 19:01:27
$dictionary["Jam01_JDB_ProductGroup"]["fields"]["jam01_jdb_company_jam01_jdb_productgroup"] = array (
  'name' => 'jam01_jdb_company_jam01_jdb_productgroup',
  'type' => 'link',
  'relationship' => 'jam01_jdb_company_jam01_jdb_productgroup',
  'source' => 'non-db',
  'module' => 'Jam01_JDB_Company',
  'bean_name' => 'Jam01_JDB_Company',
  'vname' => 'LBL_JAM01_JDB_COMPANY_JAM01_JDB_PRODUCTGROUP_FROM_JAM01_JDB_COMPANY_TITLE',
);
