<?php
 // created: 2014-03-07 13:26:50
$dictionary['Lead']['fields']['companyrevenuecurrency_c']['labelValue']='Revenue Currency';

 ?>