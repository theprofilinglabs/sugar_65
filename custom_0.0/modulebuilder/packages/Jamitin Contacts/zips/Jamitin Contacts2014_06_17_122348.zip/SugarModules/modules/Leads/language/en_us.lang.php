<?php 
 // created: 2014-06-17 12:23:47
$mod_strings['LBL_COMPANYREVENUE'] = 'Company Revenue';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_COMPANYREVENUECURRENCY'] = 'Revenue Currency';
$mod_strings['LBL_TOTALSTAFF'] = 'Total Staff';
$mod_strings['LBL_COMPANYID'] = 'CompanyId';

?>
