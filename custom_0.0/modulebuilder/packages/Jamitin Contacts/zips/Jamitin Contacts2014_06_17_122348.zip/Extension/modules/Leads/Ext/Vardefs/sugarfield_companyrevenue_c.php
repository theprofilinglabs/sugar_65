<?php
 // created: 2014-03-07 12:40:33
$dictionary['Lead']['fields']['companyrevenue_c']['options']='numeric_range_search_dom';
$dictionary['Lead']['fields']['companyrevenue_c']['labelValue']='Company Revenue';
$dictionary['Lead']['fields']['companyrevenue_c']['enable_range_search']='1';

 ?>