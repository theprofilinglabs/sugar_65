<?php
 // created: 2014-03-10 12:06:50
$dictionary['Lead']['fields']['companyid_c']['labelValue']='CompanyId';

 ?>