<?php
 // created: 2014-03-07 13:47:21
$dictionary['Lead']['fields']['totalstaff_c']['labelValue']='Total Staff';

 ?>