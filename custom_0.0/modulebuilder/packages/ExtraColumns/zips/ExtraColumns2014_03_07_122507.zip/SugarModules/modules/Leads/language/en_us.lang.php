<?php 
 // created: 2014-03-07 12:25:06
$mod_strings['LBL_COMPANYREVENUE'] = 'CompanyRevenue';

?>
