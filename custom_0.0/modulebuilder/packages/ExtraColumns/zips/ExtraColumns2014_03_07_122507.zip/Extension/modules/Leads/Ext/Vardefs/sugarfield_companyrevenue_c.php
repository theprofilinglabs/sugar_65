<?php
 // created: 2014-03-07 12:20:58
$dictionary['Lead']['fields']['companyrevenue_c']['labelValue']='CompanyRevenue';

 ?>