<?php 
 // created: 2014-05-30 13:31:50
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_JAM01_JDB_COMPANY_JAM03_JDB_CONTACTS_1_FROM_JAM01_JDB_COMPANY_TITLE'] = 'Jamitin Company';

?>
