<?php 
 // created: 2014-06-17 12:27:43
$mod_strings['LBL_DESCRIPTION'] = 'Description:';

?>
